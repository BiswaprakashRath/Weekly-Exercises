package com.library.repository;

public class BookRepository {
    public void display() {
        System.out.println("BookRepository is working!");
    }
}
